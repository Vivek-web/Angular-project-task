import { query } from '@angular/animations';
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  boxes: any  = [
    { image: null, input: false },
    { image: null, input: false },
    { image: null, input: false },
    { image: null, input: false },
    { image: null, input: false },
    { image: null, input: false }
  ];
  selectedImage: string | undefined;
  // selectedBoxIndex: any;



  
  addImage(event: Event , index:number) {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        // Find the first empty box starting from the clicked index
      for (let i = 0 ; i < this.boxes.length; i++) {
        if (this.boxes[i].image == null) {
          this.boxes[i].image = reader.result as string;
          this.boxes[i].input = false;
          break;
        }
      }
      };
    }
  }

  removeImage(index: number) {
    this.boxes[index].image = null;
    for (let i = index + 1; i < this.boxes.length; i++) {
      if (this.boxes[i].image) {
        this.boxes[index].image = this.boxes[i].image;
        this.boxes[i].image = null;
        index = i;
      }
    }
  }

  

  // onDeleteClick(event:any  , i:number ) {
  //   event.stopPropagation();
  //   let boxIndex = i;
  //   if(this.boxes[boxIndex].image == this.selectedImage){
  //     this.selectedImage = '';
  //   }
  //   this.boxes[boxIndex].image = null;

  //   for (let i = boxIndex + 1; i < this.boxes.length; i++) {
  //     if (this.boxes[i].image) {
  //       this.boxes[boxIndex].image = this.boxes[i].image;
  //       this.boxes[i].image = null;
  //       boxIndex = i;
  //     }

     
  //   }
  // }

}
